//Leia um n�mero inteiro positivo N. Para cada n�mero entre 1 e N, informe se ele � par ou �mpar.
//Ao final, exiba:
//� a quantidade de n�meros pares;
//� a quantidade de n�meros �mpares;
//� a soma dos n�meros pares.


#include <stdio.h>
#include <stdlib.h>


int main(){

    int n, par, impar, soma, i;

    printf("Digite um numero inteiro positivo: ");
    scanf("%d", &n);

    for(i =1; i<=n; i++){
        if(i%2==0){
            par ++;
            soma = soma + i;
        }
        else{
            impar ++;
        }
    }

    printf("\nA quantidade de numeros pares foi %d", par);
    printf("\nA quantidade de numeros impares foi %d", impar);
    printf("\nA soma dos pares foi = %d", soma);







}
